import {fireEvent, render, screen} from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import App from './App';

test('add todo', () => {
  render(<App />)

  const desc = screen.getByPlaceholderText('Description');
  fireEvent.change(desc, {target: { value: 'Go to coffee'} });

  const date = screen.getByPlaceholderText('Date');
  fireEvent.change(date, {target: { value: '07.03.2022' } })

  const button = screen.getByText('Add');
  fireEvent.click(button);

  const tablecell = screen.getByText(/go to coffee/i);
  expect(tablecell).toBeInTheDocument();
})